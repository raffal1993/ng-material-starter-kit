export interface AuthDataModel {
  data: {
    readonly accessToken: string;
    readonly emailVerified: false;
    readonly id: string;
    readonly refreshToken: string;
  };
}
